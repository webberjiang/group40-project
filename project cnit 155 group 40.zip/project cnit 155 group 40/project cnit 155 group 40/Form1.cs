﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_cnit_155_group_40
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private double value = 0;
        private string operation = "";
        private bool pressoperation = false;

        private const int cSize = 50;
        private double[] mresult = new double[cSize];
        private string[] mName = new string[cSize];
        private string[] moperator = new string[cSize];
        private double[] mvarl1 = new double[cSize];
        private double[] mvarl2 = new double[cSize];
        private int mindex;
        private string mFileName = Path.Combine(Application.StartupPath, "Calculator Archive.txt");

        private void DisplayMessage(string msg)
        {
            MessageBox.Show(msg, Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private bool ValidateInput()
        {

            if (txtname.Text == "")
            {
                DisplayMessage("Full name must exist .");
                txtname.Focus();
                return false;
            }
            if (radnot.Checked == false && radstore.Checked == false)
            {
                DisplayMessage("Select a store form");
                return false;
            }


            return true;
        }
        private void checkarry()
        {
            if (mindex == cSize)
            {
                DisplayMessage("Array is full.");
                btnenter.Enabled = false;
                return;
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtname.Clear();
            txtname.Focus();
            txtresult.Clear();
            lstoutput.Items.Clear();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            if ((txtresult.Text == "0") || (pressoperation))
                txtresult.Clear();
            pressoperation = false;
            Button b = (Button)sender;
            txtresult.Text = txtresult.Text + b.Text;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            txtresult.Clear();
            txtresult.Text = "0";
            value = 0;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            txtresult.Text = "0";
            lstoutput.Items.Clear();
            if (mindex == 0)
            {
                DisplayMessage("Array is empty.");
                return;
            }


            int ctr;
            for (ctr = 0; ctr < mindex; ctr++)
            {
                lstoutput.Items.Add(mName[ctr].PadRight(10) + mvarl1[ctr].ToString().PadRight(25) + moperator[ctr].PadRight(30) + mvarl2[ctr].ToString().PadRight(35) + mresult[ctr]);

            }
        }

        private void lstresult_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (File.Exists("Calculator Archive.txt") == false)
            {
                DisplayMessage("No such file.");
                return;
            }
            StreamReader SR = null;

            string[] parts;
            string line;
            try
            {
                SR = new StreamReader("Calculator Archive.txt");
                while (SR.Peek() != -1)
                {
                    line = SR.ReadLine();
                    parts = line.Split('\t');
                    mName[mindex] = parts[0];
                    mvarl1[mindex] = double.Parse(parts[1]);
                    moperator[mindex] = parts[2];
                    mvarl2[mindex] = double.Parse(parts[3]);
                    mresult[mindex] = double.Parse(parts[4]);
                    mindex++;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "runtime error");
            }
            finally
            {
                if (SR != null)
                    SR.Close();
            }
        }


        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            int ctr;

            StreamWriter SW = null;
            if (MessageBox.Show("Are you sure you want to end?", Text, MessageBoxButtons.YesNo,
                                              MessageBoxIcon.Question) == DialogResult.No)
            {
                e.Cancel = true;
                return;
            }
            try
            {
                SW = new StreamWriter("Calculator Archive.txt");
                for (ctr = 0; ctr < mindex; ctr++)
                {
                    SW.WriteLine(mName[ctr] + '\t' + mvarl1[ctr].ToString() + '\t' + moperator[ctr] + '\t' + mvarl2[ctr].ToString() + '\t' + mresult[ctr].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "runtime error");
            }
            finally
            {
                if (SW != null)
                    SW.Close();
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            if ((txtresult.Text == "0") || (pressoperation))
                txtresult.Clear();
            pressoperation = false;
            Button b = (Button)sender;
            txtresult.Text = txtresult.Text + b.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((txtresult.Text == "0") || (pressoperation))
                txtresult.Clear();
            pressoperation = false;
            Button b = (Button)sender;
            txtresult.Text = txtresult.Text + b.Text;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if ((txtresult.Text == "0") || (pressoperation))
                txtresult.Clear();
            pressoperation = false;
            Button b = (Button)sender;
            txtresult.Text = txtresult.Text + b.Text;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if ((txtresult.Text == "0") || (pressoperation))
                txtresult.Clear();
            pressoperation = false;
            Button b = (Button)sender;
            txtresult.Text = txtresult.Text + b.Text;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if ((txtresult.Text == "0") || (pressoperation))
                txtresult.Clear();
            pressoperation = false;
            Button b = (Button)sender;
            txtresult.Text = txtresult.Text + b.Text;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if ((txtresult.Text == "0") || (pressoperation))
                txtresult.Clear();
            pressoperation = false;
            Button b = (Button)sender;
            txtresult.Text = txtresult.Text + b.Text;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if ((txtresult.Text == "0") || (pressoperation))
                txtresult.Clear();
            pressoperation = false;
            Button b = (Button)sender;
            txtresult.Text = txtresult.Text + b.Text;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if ((txtresult.Text == "0") || (pressoperation))
                txtresult.Clear();
            pressoperation = false;
            Button b = (Button)sender;
            txtresult.Text = txtresult.Text + b.Text;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (txtresult.Text.IndexOf(".") == -1)
            {
                txtresult.Text = txtresult.Text + ".";
            }
            else
            {
                DisplayMessage("Already Have a decimal");
                return;
            };
        }

        private void button18_Click(object sender, EventArgs e)
        {
            txtresult.Text = "0";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if ((txtresult.Text == "0") || (pressoperation))
                txtresult.Clear();
            pressoperation = false;
            Button b = (Button)sender;
            txtresult.Text = txtresult.Text + b.Text;
        }

        private void button11_Click(object sender, EventArgs e)
        {

            if (radnot.Checked == true)
            {
                mvarl1[mindex] = 0;

            }
            else
            {
                mvarl1[mindex] = double.Parse(txtresult.Text);
            }
            Button b = (Button)sender;
            operation = "+";
            if (radnot.Checked == true)
            {

                moperator[mindex] = "";
            }
            else
            {
                moperator[mindex] = operation;
            }
            value = double.Parse(txtresult.Text);
            pressoperation = true;

        }

        private void button12_Click(object sender, EventArgs e)
        {

            double result = double.Parse(txtresult.Text);
            mvarl2[mindex] = double.Parse(txtresult.Text);

            switch (operation)
            {
                case "+":

                    txtresult.Text = (value + result).ToString();
                    mresult[mindex] = double.Parse(txtresult.Text);

                    break;
                case "-":

                    txtresult.Text = (value - result).ToString();
                    mresult[mindex] = double.Parse(txtresult.Text);

                    break;

                case "*":

                    txtresult.Text = (value * result).ToString();
                    mresult[mindex] = double.Parse(txtresult.Text);

                    break;
                case "/":
                    txtresult.Text = (value / result).ToString();
                    mresult[mindex] = double.Parse(txtresult.Text);

                    break;

                default:
                    break;

            }
            if (radnot.Checked == true)
            {
                mvarl2[mindex] = 0;
                mresult[mindex] = 0;
            }
            mindex++;


        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (radnot.Checked == true)
            {
                mvarl1[mindex] = 0;

            }
            else
            {
                mvarl1[mindex] = double.Parse(txtresult.Text);
            }

            Button b = (Button)sender;
            operation = "-";
            if (radnot.Checked == true)
            {

                moperator[mindex] = "";
            }
            else
            {
                moperator[mindex] = operation;
            }
            value = double.Parse(txtresult.Text);
            pressoperation = true;

        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (radnot.Checked == true)
            {
                mvarl1[mindex] = 0;

            }
            else
            {
                mvarl1[mindex] = double.Parse(txtresult.Text);
            }

            Button b = (Button)sender;
            operation = "*";
            if (radnot.Checked == true)
            {

                moperator[mindex] = "";
            }
            else
            {
                moperator[mindex] = operation;
            }
            value = double.Parse(txtresult.Text);
            pressoperation = true;


        }

        private void button16_Click(object sender, EventArgs e)
        {

            if (radnot.Checked == true)
            {
                mvarl1[mindex] = 0;

            }
            else
            {
                mvarl1[mindex] = double.Parse(txtresult.Text);
            }

            mindex++;
            Button b = (Button)sender;
            operation = "/";
            if (radnot.Checked == true)
            {

                moperator[mindex] = "";
            }
            else
            {
                moperator[mindex] = operation;
            }
            value = double.Parse(txtresult.Text);
            pressoperation = true;

        }

        private void btnenter_Click(object sender, EventArgs e)
        {
            if (ValidateInput() == false)
            {
                return;
            }
            mName[mindex] = txtname.Text;
            mindex++;
            checkarry();
            txtname.Focus();
        }

        private void btnenter_Click_1(object sender, EventArgs e)
        {
            if (ValidateInput() == false)
            {
                return;
            }
            if (radnot.Checked == true)
            {
                mName[mindex] = "";
            }
            else
            {
                mName[mindex] = txtname.Text;
            }
            checkarry();
            txtname.Clear();
            txtname.Focus();
        }

        private void btnsort_Click(object sender, EventArgs e)
        {
            lstoutput.Items.Clear();
            Array.Sort(mName, mresult,0, mindex);
            int ctr;
            for (ctr = 0; ctr < mindex; ctr++)
            {
                lstoutput.Items.Add(mName[ctr].PadRight(10)+mresult[ctr]);
            }
        }

    }
}
